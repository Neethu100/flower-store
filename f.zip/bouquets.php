
<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

if(isset($_POST['add_to_wishlist'])){

   $product_id = $_POST['product_id'];
   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   
   $check_wishlist_numbers = mysqli_query($conn, "SELECT * FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($check_wishlist_numbers) > 0){
       $message[] = 'already added to wishlist';
   }elseif(mysqli_num_rows($check_cart_numbers) > 0){
       $message[] = 'already added to cart';
   }else{
       mysqli_query($conn, "INSERT INTO `wishlist`(user_id, pid, name, price, image) VALUES('$user_id', '$product_id', '$product_name', '$product_price', '$product_image')") or die('query failed');
       $message[] = 'product added to wishlist';
   }

}
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>bouquets</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	
<section class="product"> 
	

	<h3>BOUQUETS</h3>
</section>
<div class ="modification">

<div class="r1">

  <div class="c1">
   <div class="b">
   	<fieldset>
    <img src="b1.jpg" alt="p1" style="width:100%">
    <p >  Mixed Flowers Bouquet</p>
      <p>$88</p>
    <a href="order.php" class="buythis">Buy Now</a><br>
    
    	<!--form-->
	
<FORM>
	<h5>Design Your Own</h5> <br>
<p> Flower Type : </p>

<p1> flower 1</p1><br>
<select class="b2">
	<option class="it" value="Rose">Rose</option>
	<option class="it" value="Lily">Lily</option>
	<option class="it" value="Jasmine">Jasmine</option>
</select><br>
<p1> flower 2</p1><br>
<select class="b2">
	<option class="it" value="Rose">Rose</option>
	<option class="it" value="lilly">lilly</option>
	<option class="it" value="jasmin">jasmin</option>
</select><br>

<br><p>Bouquet Type : </p><br>
<select class="b2">
	<option class="it" value="Shi-Jin">Shi-Jin</option>
	<option class="it" value="Blaze">Blaze</option>
	<option class="it" value="Rose cotton">Rose cotton</option>
</select><br>

<br><p>wrapping Type : </p><br>
<select class="b2">
	<option class="it" value="Black Beauty">Black Beauty</option>
	<option class="it" value="Moyeon">Moyeon</option>
	<option class="it" value="Magic Kraft">Magic Kraft</option>
</select><br>

 <a href="#" class="buythis">Buy Now</a><br>

</FORM>
</fieldset>    
    </div>

 </div>
  </div>
</div>


</body>
</html>

    