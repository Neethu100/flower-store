<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>flower    store</title><br><br>
  <link rel="stylesheet" href="css/index.css">
  <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet'>
</head>
<body>
  <div class="navbar">
    <div class="inner-width">
      <a href="#" class="logo">
        <img src="logo.png" class="logo_img">
      </div>
    </div>
  </div>
  <section id="home">
    <div class="content1">
      <div class="content">
        
       
        <a href="home.php"><button>view</button></a>
      </div>
      <div class="social-container">
      
        <div class="social-icons">
          <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
          <li><a href="#"><i class="fa fa-instagram"></i></a></li>
          <li><a href="#"><i class="fa fa-twitter"></i></a></li>
        </div>
      </div>
    </div>
    <div class="content2">
      <h1>Flower <span>Store</span></h1>
    </div>
  </section>
</body>
</html>