<?php

$conn = mysqli_connect('localhost','root','','shopdb') or die('connection failed');

?>